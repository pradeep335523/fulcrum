package com.fd.coding;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class DataFilterTest {

	
    private DataFilter dataFilter;

    @Before
    public void before(){
        dataFilter = new DataFilter(SampleData.sampleData());
    }
    
    @Test
    public void filterByCountryCode()
    {
        List<String> data = new ArrayList<>();
        data.add("IND,2022-02-03,debit card");
        data.add("IND,2022-04-01,mobile payment");
        data.add("IND,2022-03-03,credit card");
        data.add("IND,2022-01-03,bank transfer"); 
        
    	List<String> result= dataFilter.filterByCountryCode("IND");
    	assertTrue(data.size() == result.size() && data.containsAll(result) && result.containsAll(data));
    }
    
    
    @Test
    public void filterByCountryCodeAndPaymentType()
    {
        List<String> data = new ArrayList<>();
        data.add("USA,2022-01-03,credit card");
        data.add("USA,2022-03-03,credit card"); 
        
    	List<String> result= dataFilter.filterByCountryCodeAndPaymentType("USA","credit card");
  
    	assertTrue(data.size() == result.size() && data.containsAll(result) && result.containsAll(data));
    }
    
    @Test
    public void sortByTransactionDate()
    {
        List<String> data = new ArrayList<>();
        
		data.add("IND,2022-04-01,mobile payment");
		data.add("GBR,2022-04-01,credit card");
		data.add("USA,2022-04-01,bank transfer");
		data.add("IND,2022-03-03,credit card");
		data.add("GBR,2022-03-03,bank transfer");
		data.add("USA,2022-03-03,credit card");
		data.add("IND,2022-02-03,debit card");
		data.add("GBR,2022-02-03,debit card");
		data.add("USA,2022-02-03,mobile payment");
		data.add("IND,2022-01-03,bank transfer");
		data.add("GBR,2022-01-03,mobile payment");
		data.add("USA,2022-01-03,credit card");
       
    	List<String> result= dataFilter.sortByTransactionDate();
    	assertArrayEquals(result.toArray(), data.toArray()); 
    }
    
    
}
