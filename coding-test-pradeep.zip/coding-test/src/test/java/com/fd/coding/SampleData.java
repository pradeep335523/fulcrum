package com.fd.coding;

import java.util.ArrayList;
import java.util.List;

public class SampleData {
    public static List<String> sampleData(){
        List<String> data = new ArrayList<>();
        data.add("IND,2022-02-03,debit card");
        data.add("IND,2022-04-01,mobile payment");
        data.add("IND,2022-03-03,credit card");
        data.add("IND,2022-01-03,bank transfer");

        data.add("GBR,2022-04-01,credit card");
        data.add("GBR,2022-01-03,mobile payment");
        data.add("GBR,2022-03-03,bank transfer");
        data.add("GBR,2022-02-03,debit card");

        data.add("USA,2022-04-01,bank transfer");
        data.add("USA,2022-02-03,mobile payment");
        data.add("USA,2022-01-03,credit card");
        data.add("USA,2022-03-03,credit card");
        return data;

    }
}
