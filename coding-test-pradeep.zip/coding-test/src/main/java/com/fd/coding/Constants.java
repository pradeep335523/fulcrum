package com.fd.coding;

public interface Constants {
	String SAPERATOR=",";

}
