package com.fd.coding;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class DataFilter {

	private List<String> data;

	public DataFilter(List<String> data) {
		this.data = data;
	}

	/*
	 * This method will filter the data based on countryCode.
	 */
	public List<String> filterByCountryCode(String countryCode) {
		if (countryCode == null || countryCode.isBlank() || data == null || data.isEmpty())
			return Collections.emptyList();
		return data.stream().filter(s -> s.split(Constants.SAPERATOR)[0].equalsIgnoreCase(countryCode))
				.collect(Collectors.toList());
	}

	/*
	 * This method will filter the data based on countryCode and PaymentType
	 */
	public List<String> filterByCountryCodeAndPaymentType(String countryCode, String paymentType) {

		if ((countryCode == null && paymentType == null) || (countryCode.isBlank() && paymentType.isBlank()))
			return Collections.emptyList();
		if (!countryCode.isBlank() && !paymentType.isBlank()) {
			return filterByPaymentType(filterByCountryCode(countryCode), paymentType);

		} else if (!countryCode.isBlank()) {
			return filterByCountryCode(countryCode);
		} else

			return filterByPaymentType(data, paymentType);
	}

	/*
	 * This method is used to sort the data based on transaction date - Ascending Order.
	 */
	public List<String> sortByTransactionDate() {

		if (data == null || data.isEmpty()) {
			return Collections.emptyList();
		}

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Comparator<String> dComparator = (d2, d1) -> {
			try {
				return sdf.parse(d1.split(Constants.SAPERATOR)[1]).compareTo(sdf.parse(d2.split(Constants.SAPERATOR)[1]));
			} catch (ParseException e) {

				e.printStackTrace();
			}
			return 0;
		};
		return data.stream().sorted(dComparator).collect(Collectors.toList());
	}

	/*
	 * This method is added by Candidate to filter the data based on payment type -
	 * Pradeep Kumar
	 */
	private List<String> filterByPaymentType(List<String> filteredData, String paymentType) {
		if (paymentType == null || paymentType.isBlank() || filteredData == null || filteredData.isEmpty())
			return Collections.emptyList();
		return filteredData.stream().filter(s -> s.split(Constants.SAPERATOR)[2].equalsIgnoreCase(paymentType))
				.collect(Collectors.toList());
	}

}
