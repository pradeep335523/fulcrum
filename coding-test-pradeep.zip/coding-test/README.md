# Problem:

A program is required to filer transaction extracts based by number of different properties. The transaction extracts contains Country Code, Transaction Date and Payment Type in comma-separated value format. The
sample data set is provided in the Test Sources.  Please write a program to meet this requirement, you must also write test cases to ensure that the features you have implemented work correctly.

The date format is DateTimeFormatter.ISO_LOCAL_DATE

Example data set:

| Country Code	 | Transaction Date	 | Payment Type  |
|---------------|-------------------|---------------|
| IND	          | 2022-02-03	       | debit card    |
| GBR           | 2022-03-03	       | bank transfer |
| IND           | 2022-04-01	       | mobile payment |
| USA           | 2022-01-03	       | credit card   |

You are required to the following filters
1. filterByCountryCode, example : if Country Code = IND, should return row 1
2. filterByCountryCodeAndPaymentType, example : if countryCode = GBR and Payment Type = bank transfer, should return row 2
3. sortByTransactionDate in chronologically order as below

| Country Code	 | Transaction Date	 | Payment Type   |
|---------------|-------------------|----------------|
| USA	          | 2022-01-03	       | credit card    |
| IND           | 2022-02-03	       | debit card     |
| GBR           | 2022-03-03	       | bank transfer  |
| IND           | 2022-04-01	       | mobile payment |

The required methods have been prototyped in the class com.fd.coding.DataFilter. You must implement the
features in this class without changing the signatures of any methods in DataFilter or add any new maven dependencies, please feel free to add any new classes as required. 
The time allotted to the test is 1 hour.  Incomplete solutions are acceptable and the solution will be judged on good software development practice and the unit tests to cover possible scenarios